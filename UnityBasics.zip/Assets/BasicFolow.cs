using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicFolow : MonoBehaviour
{
    private GameObject cube = GameObject.Find("PlayerChar");
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if (cube != null)
        {
            this.transform.LookAt(cube);
        }
    }
}
